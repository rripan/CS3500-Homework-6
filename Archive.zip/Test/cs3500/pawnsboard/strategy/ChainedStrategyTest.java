package cs3500.pawnsboard.strategy;

import cs3500.pawnsboard.model.Card;
import cs3500.pawnsboard.model.CardImp;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.Player;
import cs3500.pawnsboard.model.mock.MockPawnsBoardModel;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Unit tests for the ChainedStrategy class, which attempts multiple strategies in sequence.
 */
public class ChainedStrategyTest {

  private ReadonlyPawnsBoardModel model;
  private List<Card> redHand;
  private List<Card> blueHand;
  private Strategy fillFirstStrategy;
  private Strategy maximizeRowScoreStrategy;
  private Strategy controlBoardStrategy;
  private Strategy chainedStrategy;

  /**
   * Sets up a mock board and multiple strategy implementations before each test.
   */
  @Before
  public void setUp() {
    redHand = new ArrayList<>();
    blueHand = new ArrayList<>();
    String[] influenceGrid = {
            "XXXXX",
            "XXIXX",
            "XICIX",
            "XXIXX",
            "XXXXX"
    };

    redHand.add(new CardImp("Attack", 2, 5, influenceGrid));
    redHand.add(new CardImp("Boost", 1, 3, influenceGrid));
    blueHand.add(new CardImp("Defense", 1, 3, influenceGrid));

    model = new MockPawnsBoardModel(
            new StringBuilder(),
            Player.RED,
            5,
            5,
            true,
            Player.RED,
            new ArrayList<>(),
            new ArrayList<>(),
            new ArrayList<>(),
            redHand,
            blueHand,
            new int[5][2]
    );

    fillFirstStrategy = new FillFirstStrategy();
    maximizeRowScoreStrategy = new MaximizeRowScoreStrategy();
    controlBoardStrategy = new ControlBoardStrategy();
    chainedStrategy = new ChainedStrategy(List.of(
            fillFirstStrategy,
            maximizeRowScoreStrategy,
            controlBoardStrategy
    ));
  }

  /**
   * Tests that ChainedStrategy returns null when all strategies fail to produce a move.
   */
  @Test
  public void testChainedStrategyFallback() {
    model = new MockPawnsBoardModel(
            new StringBuilder(), Player.RED, 5, 5, true, Player.RED,
            new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            new ArrayList<>(), new ArrayList<>(), new int[5][2]
    );

    chainedStrategy = new ChainedStrategy(List.of(
            fillFirstStrategy,
            maximizeRowScoreStrategy
    ));
    Strategy.Move move = chainedStrategy.chooseMove(model, Player.RED);
    assertNull("ChainedStrategy should return null if all strategies fail", move);
  }

  /**
   * Tests that ChainedStrategy prioritizes the first strategy in the chain.
   */
  @Test
  public void testChainedStrategyPrefersFirstStrategy() {
    Strategy.Move move = chainedStrategy.chooseMove(model, Player.RED);
    Strategy.Move fillFirstMove = fillFirstStrategy.chooseMove(model, Player.RED);
    assertEquals("ChainedStrategy should pick the first strategy's move", fillFirstMove,
            move);
  }

  /**
   * Tests that ChainedStrategy uses MaximizeRowScoreStrategy if FillFirst fails.
   */
  @Test
  public void testChainedStrategyUsesMaximizeRowScore() {
    model = new MockPawnsBoardModel(
            new StringBuilder(), Player.RED, 5, 5, true, Player.RED,
            new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            new ArrayList<>(), blueHand, new int[5][2]
    );

    chainedStrategy = new ChainedStrategy(List.of(
            fillFirstStrategy,
            maximizeRowScoreStrategy
    ));

    Strategy.Move move = chainedStrategy.chooseMove(model, Player.RED);
    Strategy.Move expectedMove = maximizeRowScoreStrategy.chooseMove(model, Player.RED);

    assertEquals("ChainedStrategy should pick MaximizeRowScore if FillFirst fails",
            expectedMove, move);
  }

  /**
   * Tests that ChainedStrategy uses ControlBoardStrategy if earlier strategies fail.
   */
  @Test
  public void testChainedStrategyUsesControlBoardStrategy() {
    model = new MockPawnsBoardModel(
            new StringBuilder(), Player.RED, 5, 5, true, Player.RED,
            new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            new ArrayList<>(), new ArrayList<>(), new int[5][2]
    );

    chainedStrategy = new ChainedStrategy(List.of(
            fillFirstStrategy,
            maximizeRowScoreStrategy,
            controlBoardStrategy
    ));

    Strategy.Move move = chainedStrategy.chooseMove(model, Player.RED);
    Strategy.Move expectedMove = controlBoardStrategy.chooseMove(model, Player.RED);

    assertEquals("ChainedStrategy should pick ControlBoardStrategy if others fail",
            expectedMove, move);
  }

  /**
   * Tests that ChainedStrategy works with only one strategy in its chain.
   */
  @Test
  public void testChainedStrategyWithOneStrategy() {
    chainedStrategy = new ChainedStrategy(List.of(fillFirstStrategy));
    Strategy.Move move = chainedStrategy.chooseMove(model, Player.RED);
    Strategy.Move expectedMove = fillFirstStrategy.chooseMove(model, Player.RED);

    assertEquals("ChainedStrategy with one strategy should behave like that strategy",
            expectedMove, move);
  }

  /**
   * Tests that ChainedStrategy returns null gracefully when no strategies return a move.
   */
  @Test
  public void testChainedStrategyFailsGracefully() {
    model = new MockPawnsBoardModel(
            new StringBuilder(), Player.RED, 5, 5, true, Player.RED,
            new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
            new ArrayList<>(), new ArrayList<>(), new int[5][2]
    );

    chainedStrategy = new ChainedStrategy(List.of(
            fillFirstStrategy,
            maximizeRowScoreStrategy,
            controlBoardStrategy
    ));

    Strategy.Move move = chainedStrategy.chooseMove(model, Player.RED);
    assertNull("ChainedStrategy should return null when no strategies work", move);
  }
}