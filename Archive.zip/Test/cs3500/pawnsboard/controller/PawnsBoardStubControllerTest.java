package cs3500.pawnsboard.controller;

import cs3500.pawnsboard.model.Card;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.Player;
import cs3500.pawnsboard.view.PawnsBoardGUIView;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the {@link PawnsBoardStubController} class.
 * These tests verify how the controller interacts with a mock model and GUI view.
 */
public class PawnsBoardStubControllerTest {

  private PawnsBoardStubController controller;
  private MockModel model;
  private MockView view;
  private ByteArrayOutputStream outContent;
  private PrintStream originalOut;

  /**
   * A mock implementation of ReadonlyPawnsBoardModel for testing controller logic.
   */
  private static class MockModel implements ReadonlyPawnsBoardModel {
    private final Player currentPlayer;

    public MockModel(Player currentPlayer) {
      this.currentPlayer = currentPlayer;
    }

    @Override
    public Player getCurrentPlayer() {
      return currentPlayer;
    }

    @Override
    public List<Card> getPlayerHand(Player player) {
      return new ArrayList<>();
    }

    @Override
    public int getRows() {
      return 0;
    }

    @Override
    public int getColumns() {
      return 0;
    }

    @Override
    public CellContent getCellContent(int row, int col) {
      return null;
    }

    @Override
    public Player getCellOwner(int row, int col) {
      return null;
    }

    @Override
    public int getPawnCount(int row, int col) {
      return 0;
    }

    @Override
    public Card getCard(int row, int col) {
      return null;
    }

    @Override
    public int getRowScore(Player player, int row) {
      return 0;
    }

    @Override
    public int getTotalScore(Player player) {
      return 0;
    }

    @Override
    public boolean isGameOver() {
      return false;
    }

    @Override
    public Player getWinner() {
      return null;
    }

    @Override
    public boolean hasPlayerPassed(Player player) {
      return false;
    }

    @Override
    public boolean isLegalMove(int cardIndex, int row, int col) {
      return false;
    }
  }

  /**
   * A mock implementation of PawnsBoardGUIView for observing GUI behavior.
   */
  private static class MockView implements PawnsBoardGUIView {
    private int highlightedCardIndex = -1;
    private int highlightedRow = -1;
    private int highlightedCol = -1;
    private boolean highlightsCleared = false;

    @Override
    public void setVisible(boolean visible) {
      // No implementation needed for tests
    }

    @Override
    public void refresh() {
      // No implementation needed for tests
    }

    @Override
    public void highlightCard(int cardIndex) {
      this.highlightedCardIndex = cardIndex;
      this.highlightedRow = -1;
      this.highlightedCol = -1;
      this.highlightsCleared = false;
    }

    @Override
    public void highlightCell(int row, int col) {
      this.highlightedRow = row;
      this.highlightedCol = col;
      this.highlightedCardIndex = -1;
      this.highlightsCleared = false;
    }

    @Override
    public void clearHighlights() {
      this.highlightedCardIndex = -1;
      this.highlightedRow = -1;
      this.highlightedCol = -1;
      this.highlightsCleared = true;
    }

    @Override
    public void displayMessage(String message) {
      // No implementation needed for tests
    }

    @Override
    public void addFeatures(Features f) {
      //idk
    }

    public int getHighlightedCardIndex() {
      return highlightedCardIndex;
    }

    public int getHighlightedRow() {
      return highlightedRow;
    }

    public int getHighlightedCol() {
      return highlightedCol;
    }

    public boolean isHighlightsCleared() {
      return highlightsCleared;
    }
  }

  /**
   * Sets up mock model/view and output stream capture before each test.
   */
  @Before
  public void setUp() {
    originalOut = System.out;
    outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

    model = new MockModel(Player.RED);
    view = new MockView();
    controller = new PawnsBoardStubController(model, view);
  }

  /**
   * Restores original System.out after each test.
   */
  @After
  public void tearDown() {
    System.setOut(originalOut);
  }

  /**
   * Tests selecting a card for the first time.
   */
  @Test
  public void testHandleCardClick_FirstTimeSelectsCard() {
    controller.handleCardClick(2);
    assertEquals(2, view.getHighlightedCardIndex());
    assertFalse(view.isHighlightsCleared());

    String output = outContent.toString();
    assertTrue(output.contains("Card clicked: 2"));
    assertTrue(output.contains("owned by RED"));
  }

  /**
   * Tests clicking the same card again to deselect it.
   */
  @Test
  public void testHandleCardClick_SecondTimeDeselectsCard() {
    controller.handleCardClick(3);
    outContent.reset();
    controller.handleCardClick(3);

    assertEquals(-1, view.getHighlightedCardIndex());
    assertTrue(view.isHighlightsCleared());

    String output = outContent.toString();
    assertTrue(output.contains("Card clicked: 3"));
  }

  /**
   * Tests selecting a different card switches highlight.
   */
  @Test
  public void testHandleCardClick_DifferentCardSwitchesSelection() {
    controller.handleCardClick(1);
    outContent.reset();
    controller.handleCardClick(4);

    assertEquals(4, view.getHighlightedCardIndex());
    assertFalse(view.isHighlightsCleared());

    String output = outContent.toString();
    assertTrue(output.contains("Card clicked: 4"));
  }

  /**
   * Tests selecting a cell for the first time.
   */
  @Test
  public void testHandleCellClick_FirstTimeSelectsCell() {
    controller.handleCellClick(2, 3);
    assertEquals(2, view.getHighlightedRow());
    assertEquals(3, view.getHighlightedCol());
    assertFalse(view.isHighlightsCleared());

    String output = outContent.toString();
    assertTrue(output.contains("Cell clicked: (2,3)"));
  }

  /**
   * Tests clicking the same cell again to deselect it.
   */
  @Test
  public void testHandleCellClick_SecondTimeDeselectsCell() {
    controller.handleCellClick(1, 4);
    outContent.reset();
    controller.handleCellClick(1, 4);

    assertEquals(-1, view.getHighlightedRow());
    assertEquals(-1, view.getHighlightedCol());
    assertTrue(view.isHighlightsCleared());

    String output = outContent.toString();
    assertTrue(output.contains("Cell clicked: (1,4)"));
  }

  /**
   * Tests switching between two different cells.
   */
  @Test
  public void testHandleCellClick_DifferentCellSwitchesSelection() {
    controller.handleCellClick(1, 1);
    outContent.reset();
    controller.handleCellClick(3, 2);

    assertEquals(3, view.getHighlightedRow());
    assertEquals(2, view.getHighlightedCol());
    assertFalse(view.isHighlightsCleared());

    String output = outContent.toString();
    assertTrue(output.contains("Cell clicked: (3,2)"));
  }

  /**
   * Tests confirming a move logs the appropriate message.
   */
  @Test
  public void testHandleConfirmMove() {
    controller.handleConfirmMove();
    String output = outContent.toString();
    assertTrue(output.contains("Confirm move key pressed"));
  }

  /**
   * Tests passing the turn logs the appropriate message.
   */
  @Test
  public void testHandlePassTurn() {
    controller.handlePassTurn();
    String output = outContent.toString();
    assertTrue(output.contains("Pass turn key pressed"));
  }

  /**
   * Tests selecting a card and then switching to cell selection.
   */
  @Test
  public void testCardSelectCellSelectInteraction() {
    controller.handleCardClick(2);
    controller.handleCellClick(1, 3);

    assertEquals(-1, view.getHighlightedCardIndex());
    assertEquals(1, view.getHighlightedRow());
    assertEquals(3, view.getHighlightedCol());
  }
}