package cs3500.pawnsboard.model;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Tests for the DeckConfigReader class.
 */
public class DeckConfigReaderTests {

  private File testFile;

  @Before
  public void setUp() throws IOException {
    // Create a temporary file for testing
    testFile = File.createTempFile("test_deck", ".txt");
    testFile.deleteOnExit();

    // Write test deck configuration to the file
    FileWriter writer = null;
    try {
      writer = new FileWriter(testFile);
      writer.write("TestCard1 1 2\n");
      writer.write("XXXXX\n");
      writer.write("XXXXX\n");
      writer.write("XXCXX\n");
      writer.write("XXXXX\n");
      writer.write("XXXXX\n");
      writer.write("TestCard2 2 3\n");
      writer.write("XXXXX\n");
      writer.write("XIXIX\n");
      writer.write("XICIX\n");
      writer.write("XIXIX\n");
      writer.write("XXXXX\n");
    } finally {
      if (writer != null) {
        writer.close();
      }
    }
  }

  @After
  public void tearDown() {
    // Delete the temporary file
    if (testFile != null && testFile.exists()) {
      testFile.delete();
    }
  }

  @Test
  public void testReadDeck() {
    List<Card> deck = DeckConfigReader.readDeck(testFile.getAbsolutePath());

    // Check deck size and card properties
    assertEquals(2, deck.size());

    Card card1 = deck.get(0);
    assertEquals("TestCard1", card1.getName());
    assertEquals(1, card1.getCost());
    assertEquals(2, card1.getValueScore());

    Card card2 = deck.get(1);
    assertEquals("TestCard2", card2.getName());
    assertEquals(2, card2.getCost());
    assertEquals(3, card2.getValueScore());

    // Check influence grids
    String[] influenceGrid1 = card1.getInfluenceGrid();
    assertEquals("XXXXX", influenceGrid1[0]);
    assertEquals("XXCXX", influenceGrid1[2]);

    String[] influenceGrid2 = card2.getInfluenceGrid();
    assertEquals("XIXIX", influenceGrid2[1]);
    assertEquals("XICIX", influenceGrid2[2]);
  }

  @Test
  public void testReadEmptyDeck() throws IOException {
    // Create an empty file
    File emptyFile = File.createTempFile("empty_deck", ".txt");
    emptyFile.deleteOnExit();

    // Read the empty deck
    List<Card> deck = DeckConfigReader.readDeck(emptyFile.getAbsolutePath());

    // Check that the deck is empty
    assertTrue(deck.isEmpty());
  }

  @Test
  public void testDeckWithInvalidFile() {
    // Try to read a non-existent file
    List<Card> deck = DeckConfigReader.readDeck("non_existent_file.txt");

    // Should return an empty list
    assertTrue(deck.isEmpty());
  }

  @Test
  public void testDeckWithInvalidCardFormat() throws IOException {
    // Create a file with invalid card format
    File invalidFile = File.createTempFile("invalid_deck", ".txt");
    invalidFile.deleteOnExit();

    FileWriter writer = null;
    try {
      writer = new FileWriter(invalidFile);
      writer.write("InvalidCard\n"); // Missing cost and value
      writer.write("XXXXX\n");
      writer.write("XXXXX\n");
      writer.write("XXCXX\n");
      writer.write("XXXXX\n");
      writer.write("XXXXX\n");
    } finally {
      if (writer != null) {
        writer.close();
      }
    }

    try {
      DeckConfigReader.readDeck(invalidFile.getAbsolutePath());
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
  }

  @Test
  public void testDeckWithIncompleteGrid() throws IOException {
    // Create a file with incomplete influence grid
    File incompleteFile = File.createTempFile("incomplete_deck", ".txt");
    incompleteFile.deleteOnExit();

    FileWriter writer = null;
    try {
      writer = new FileWriter(incompleteFile);
      writer.write("IncompleteCard 1 2\n");
      writer.write("XXXXX\n");
      writer.write("XXXXX\n");
      writer.write("XXCXX\n");
      // Missing two rows
    } finally {
      if (writer != null) {
        writer.close();
      }
    }

    try {
      DeckConfigReader.readDeck(incompleteFile.getAbsolutePath());
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
  }
}