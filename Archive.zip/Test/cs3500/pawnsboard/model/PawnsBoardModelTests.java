package cs3500.pawnsboard.model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the {@link PawnsBoardModelImpl} implementation.
 * Covers functionality like game setup, card placement, turn logic, game state, and model copying.
 */
public class PawnsBoardModelTests {
  private PawnsBoardModel model;
  private List<Card> redDeck;
  private List<Card> blueDeck;

  /**
   * Sets up the model and initializes test decks for each player.
   */
  @Before
  public void setUp() {
    model = new PawnsBoardModelImpl(1234); // Fixed seed for consistent tests
    redDeck = createTestDeck("Red");
    blueDeck = createTestDeck("Blue");
  }

  /**
   * Creates a deck of test cards with named prefixes.
   *
   * @param prefix the string to prepend to card names
   * @return list of test cards
   */
  private List<Card> createTestDeck(String prefix) {
    List<Card> deck = new ArrayList<>();

    String[] basicGrid = {
            "XXXXX",
            "XXXXX",
            "XXCXX",
            "XXXXX",
            "XXXXX"
    };

    String[] crossGrid = {
            "XXXXX",
            "XIXIX",
            "XICIX",
            "XIXIX",
            "XXXXX"
    };

    // Create 15 cards (enough for 3x5 board)
    for (int i = 1; i <= 10; i++) {
      deck.add(new CardImp(prefix + "Basic" + i, 1, i, basicGrid));
    }

    for (int i = 1; i <= 5; i++) {
      deck.add(new CardImp(prefix + "Cross" + i, 2, i + 10, crossGrid));
    }

    return deck;
  }

  @Test
  public void testInitGameValidParameters() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    assertEquals(3, model.getRows());
    assertEquals(5, model.getColumns());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInitGameInvalidRows() {
    model.initGame(0, 5, redDeck, blueDeck, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInitGameInvalidCols() {
    model.initGame(3, 2, redDeck, blueDeck, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInitGameInvalidHandSize() {
    model.initGame(3, 5, redDeck, blueDeck, 10); // Hand size too big
  }

  @Test
  public void testStartGame() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    assertEquals(ReadonlyPawnsBoardModel.Player.RED, model.getCurrentPlayer());
    assertEquals(3, model.getPlayerHand(ReadonlyPawnsBoardModel.Player.RED).size());
    assertEquals(3, model.getPlayerHand(ReadonlyPawnsBoardModel.Player.BLUE).size());

    for (int r = 0; r < 3; r++) {
      assertEquals(ReadonlyPawnsBoardModel.CellContent.PAWN, model.getCellContent(r, 0));
      assertEquals(ReadonlyPawnsBoardModel.Player.RED, model.getCellOwner(r, 0));
      assertEquals(1, model.getPawnCount(r, 0));

      assertEquals(ReadonlyPawnsBoardModel.CellContent.PAWN, model.getCellContent(r, 4));
      assertEquals(ReadonlyPawnsBoardModel.Player.BLUE, model.getCellOwner(r, 4));
      assertEquals(1, model.getPawnCount(r, 4));

      for (int c = 1; c < 4; c++) {
        assertEquals(ReadonlyPawnsBoardModel.CellContent.EMPTY, model.getCellContent(r, c));
        assertNull(model.getCellOwner(r, c));
        assertEquals(0, model.getPawnCount(r, c));
      }
    }
  }

  @Test(expected = IllegalStateException.class)
  public void testStartGameTwice() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();
    model.startGame(); // Should throw
  }

  @Test
  public void testPassTurn() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    assertEquals(ReadonlyPawnsBoardModel.Player.RED, model.getCurrentPlayer());
    model.passTurn();
    assertEquals(ReadonlyPawnsBoardModel.Player.BLUE, model.getCurrentPlayer());
    model.passTurn();
    assertEquals(ReadonlyPawnsBoardModel.Player.RED, model.getCurrentPlayer());
  }

  @Test
  public void testIsGameOver() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    assertFalse(model.isGameOver());

    model.passTurn();
    model.passTurn();

    assertTrue(model.isGameOver());
  }

  @Test
  public void testPlaceCard() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    List<Card> redHand = model.getPlayerHand(ReadonlyPawnsBoardModel.Player.RED);
    int cardIndex = -1;
    for (int i = 0; i < redHand.size(); i++) {
      if (redHand.get(i).getCost() == 1) {
        cardIndex = i;
        break;
      }
    }

    if (cardIndex >= 0) {
      model.placeCard(cardIndex, 0, 0);

      assertEquals(ReadonlyPawnsBoardModel.CellContent.CARD, model.getCellContent(0, 0));
      assertEquals(ReadonlyPawnsBoardModel.Player.RED, model.getCellOwner(0, 0));
      assertEquals(ReadonlyPawnsBoardModel.Player.BLUE, model.getCurrentPlayer());
      assertEquals(2, model.getPlayerHand(ReadonlyPawnsBoardModel.Player.RED).size());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlaceCardInvalidCardIndex() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();
    model.placeCard(10, 0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlaceCardInvalidCell() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();
    model.placeCard(0, 0, 2);
  }

  @Test
  public void testGetWinner() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();
    model.passTurn();
    model.passTurn();

    assertTrue(model.isGameOver());
    assertNull(model.getWinner()); // Tie
  }

  @Test
  public void testHasPlayerPassed() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    assertFalse(model.hasPlayerPassed(ReadonlyPawnsBoardModel.Player.RED));
    assertFalse(model.hasPlayerPassed(ReadonlyPawnsBoardModel.Player.BLUE));

    model.passTurn();
    assertTrue(model.hasPlayerPassed(ReadonlyPawnsBoardModel.Player.RED));
  }

  @Test
  public void testCopy() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    PawnsBoardModel copy = (PawnsBoardModel) model.copy();

    assertEquals(model.getRows(), copy.getRows());
    assertEquals(model.getColumns(), copy.getColumns());
    assertEquals(model.getCurrentPlayer(), copy.getCurrentPlayer());
    assertEquals(model.isGameOver(), copy.isGameOver());

    for (int r = 0; r < model.getRows(); r++) {
      for (int c = 0; c < model.getColumns(); c++) {
        assertEquals(model.getCellContent(r, c), copy.getCellContent(r, c));
        assertEquals(model.getCellOwner(r, c), copy.getCellOwner(r, c));
        assertEquals(model.getPawnCount(r, c), copy.getPawnCount(r, c));
      }
    }

    assertEquals(
            model.getPlayerHand(ReadonlyPawnsBoardModel.Player.RED).size(),
            copy.getPlayerHand(ReadonlyPawnsBoardModel.Player.RED).size()
    );

    assertEquals(
            model.getPlayerHand(ReadonlyPawnsBoardModel.Player.BLUE).size(),
            copy.getPlayerHand(ReadonlyPawnsBoardModel.Player.BLUE).size()
    );
  }

  @Test
  public void testIsLegalMove() {
    model.initGame(3, 5, redDeck, blueDeck, 3);
    model.startGame();

    List<Card> redHand = model.getPlayerHand(ReadonlyPawnsBoardModel.Player.RED);
    int cardIndex = -1;
    for (int i = 0; i < redHand.size(); i++) {
      if (redHand.get(i).getCost() == 1) {
        cardIndex = i;
        break;
      }
    }

    if (cardIndex >= 0) {
      assertTrue(model.isLegalMove(cardIndex, 0, 0));
      assertFalse(model.isLegalMove(cardIndex, 0, 1));
      assertFalse(model.isLegalMove(cardIndex, 0, 4));
      assertFalse(model.isLegalMove(10, 0, 0));
    }
  }
}