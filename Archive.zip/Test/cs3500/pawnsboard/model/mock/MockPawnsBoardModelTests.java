package cs3500.pawnsboard.model.mock;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import cs3500.pawnsboard.model.Card;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.CellContent;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.Player;

/**
 * Tests for the MockPawnsBoardModel class.
 */
public class MockPawnsBoardModelTests {
  private StringBuilder log;
  private MockPawnsBoardModel mockModel;

  @Before
  public void setUp() {
    log = new StringBuilder();

    // Create a simple 3x5 board
    List<List<CellContent>> boardContents = new ArrayList<>();
    List<List<Player>> boardOwners = new ArrayList<>();
    List<List<Integer>> pawnCounts = new ArrayList<>();

    // Initialize board content, owners, and pawn counts
    for (int i = 0; i < 3; i++) {
      boardContents.add(new ArrayList<>());
      boardOwners.add(new ArrayList<>());
      pawnCounts.add(new ArrayList<>());

      for (int j = 0; j < 5; j++) {
        boardContents.get(i).add(CellContent.EMPTY);
        boardOwners.get(i).add(null);
        pawnCounts.get(i).add(0);
      }
    }

    // Set up a standard starting board with pawns on the left for Red and right for Blue
    for (int i = 0; i < 3; i++) {
      // Red pawns in first column
      boardContents.get(i).set(0, CellContent.PAWN);
      boardOwners.get(i).set(0, Player.RED);
      pawnCounts.get(i).set(0, 1);

      // Blue pawns in last column
      boardContents.get(i).set(4, CellContent.PAWN);
      boardOwners.get(i).set(4, Player.BLUE);
      pawnCounts.get(i).set(4, 1);
    }

    // Set up mock cards
    String[] basicInfluenceGrid = {
            "XXXXX",
            "XXXXX",
            "XXCXX",
            "XXXXX",
            "XXXXX"
    };

    // Create hands
    List<Card> redHand = new ArrayList<>();
    redHand.add(new MockCard("Basic1", 1, 1, basicInfluenceGrid));

    List<Card> blueHand = new ArrayList<>();
    blueHand.add(new MockCard("Basic1", 1, 1, basicInfluenceGrid));

    // Initialize row scores (red, blue)
    int[][] rowScores = new int[3][2];
    rowScores[0] = new int[] {1, 0};
    rowScores[1] = new int[] {0, 1};
    rowScores[2] = new int[] {2, 2};

    // Create the mock model
    mockModel = new MockPawnsBoardModel(
            log,
            Player.RED,
            3, 5,
            false, null,
            boardContents,
            boardOwners,
            pawnCounts,
            redHand,
            blueHand,
            rowScores
    );
  }

  @Test
  public void testGetCurrentPlayer() {
    assertEquals(Player.RED, mockModel.getCurrentPlayer());
    assertTrue(log.toString().contains("getCurrentPlayer()"));
  }

  @Test
  public void testGetPlayerHand() {
    List<Card> hand = mockModel.getPlayerHand(Player.RED);
    assertEquals(1, hand.size());
    assertEquals("Basic1", hand.get(0).getName());
    assertTrue(log.toString().contains("getPlayerHand(RED)"));
  }

  @Test
  public void testGetRows() {
    assertEquals(3, mockModel.getRows());
    assertTrue(log.toString().contains("getRows()"));
  }

  @Test
  public void testGetColumns() {
    assertEquals(5, mockModel.getColumns());
    assertTrue(log.toString().contains("getColumns()"));
  }

  @Test
  public void testGetCellContent() {
    assertEquals(CellContent.PAWN, mockModel.getCellContent(0, 0));
    assertEquals(CellContent.EMPTY, mockModel.getCellContent(0, 1));
    assertTrue(log.toString().contains("getCellContent(0,0)"));
    assertTrue(log.toString().contains("getCellContent(0,1)"));
  }

  @Test
  public void testGetCellOwner() {
    assertEquals(Player.RED, mockModel.getCellOwner(0, 0));
    assertNull(mockModel.getCellOwner(0, 1));
    assertTrue(log.toString().contains("getCellOwner(0,0)"));
    assertTrue(log.toString().contains("getCellOwner(0,1)"));
  }

  @Test
  public void testGetPawnCount() {
    assertEquals(1, mockModel.getPawnCount(0, 0));
    assertEquals(0, mockModel.getPawnCount(0, 1));
    assertTrue(log.toString().contains("getPawnCount(0,0)"));
    assertTrue(log.toString().contains("getPawnCount(0,1)"));
  }

  @Test
  public void testHasPlayerPassed() {
    assertFalse(mockModel.hasPlayerPassed(Player.RED));
    assertFalse(mockModel.hasPlayerPassed(Player.BLUE));
    assertTrue(log.toString().contains("hasPlayerPassed(RED)"));
    assertTrue(log.toString().contains("hasPlayerPassed(BLUE)"));
  }

  @Test
  public void testIsLegalMove() {
    // Valid move
    assertTrue(mockModel.isLegalMove(0, 0, 0));

    // Invalid moves
    assertFalse(mockModel.isLegalMove(0, 0, 1)); // Not a pawn
    assertFalse(mockModel.isLegalMove(0, 0, 4)); // Wrong owner
    assertFalse(mockModel.isLegalMove(1, 0, 0)); // Invalid card index

    assertTrue(log.toString().contains("isLegalMove(0,0,0)"));
    assertTrue(log.toString().contains("isLegalMove(0,0,1)"));
    assertTrue(log.toString().contains("isLegalMove(0,0,4)"));
    assertTrue(log.toString().contains("isLegalMove(1,0,0)"));
  }

  @Test
  public void testGetLog() {
    mockModel.getCurrentPlayer();
    mockModel.getRows();
    mockModel.getColumns();

    String logContent = mockModel.getLog();
    assertTrue(logContent.contains("getCurrentPlayer()"));
    assertTrue(logContent.contains("getRows()"));
    assertTrue(logContent.contains("getColumns()"));
  }
}