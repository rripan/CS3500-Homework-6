package cs3500.pawnsboard.model.mock;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import cs3500.pawnsboard.model.Card;

/**
 * Test suite for the MockCard class.
 */
public class MockCardTest {
  private MockCard basicCard;
  private MockCard complexCard;
  private String[] basicGrid;
  private String[] complexGrid;

  @Before
  public void setUp() {
    // Create a basic influence grid with just a center
    basicGrid = new String[]{
            "XXXXX",
            "XXXXX",
            "XXCXX",
            "XXXXX",
            "XXXXX"
    };

    // Create a more complex influence grid with influence points
    complexGrid = new String[]{
            "XXXXX",
            "XIXXX",
            "XICIX",
            "XIXXX",
            "XXXXX"
    };

    basicCard = new MockCard("Basic Card", 1, 5, basicGrid);
    complexCard = new MockCard("Complex Card", 3, 15, complexGrid);
  }

  @Test
  public void testGetName() {
    assertEquals("Basic Card", basicCard.getName());
    assertEquals("Complex Card", complexCard.getName());
  }

  @Test
  public void testGetCost() {
    assertEquals(1, basicCard.getCost());
    assertEquals(3, complexCard.getCost());
  }

  @Test
  public void testGetValueScore() {
    assertEquals(5, basicCard.getValueScore());
    assertEquals(15, complexCard.getValueScore());
  }

  @Test
  public void testGetInfluenceGrid() {
    String[] retrievedBasicGrid = basicCard.getInfluenceGrid();
    String[] retrievedComplexGrid = complexCard.getInfluenceGrid();

    // Check same length
    assertEquals(basicGrid.length, retrievedBasicGrid.length);
    assertEquals(complexGrid.length, retrievedComplexGrid.length);

    // Check actual content
    for (int i = 0; i < basicGrid.length; i++) {
      assertEquals(basicGrid[i], retrievedBasicGrid[i]);
    }

    for (int i = 0; i < complexGrid.length; i++) {
      assertEquals(complexGrid[i], retrievedComplexGrid[i]);
    }

    // Ensure returned grid is a defensive copy
    retrievedBasicGrid[0] = "IIIII";
    assertNotEquals("IIIII", basicCard.getInfluenceGrid()[0]);
  }

  @Test
  public void testCopy() {
    Card basicCopy = basicCard.copy();
    Card complexCopy = complexCard.copy();

    // Verify they're not the same object
    assertNotSame(basicCard, basicCopy);
    assertNotSame(complexCard, complexCopy);

    // Verify all properties are the same
    assertEquals(basicCard.getName(), basicCopy.getName());
    assertEquals(basicCard.getCost(), basicCopy.getCost());
    assertEquals(basicCard.getValueScore(), basicCopy.getValueScore());

    assertEquals(complexCard.getName(), complexCopy.getName());
    assertEquals(complexCard.getCost(), complexCopy.getCost());
    assertEquals(complexCard.getValueScore(), complexCopy.getValueScore());

    // Check influence grid is the same
    String[] originalGrid = basicCard.getInfluenceGrid();
    String[] copiedGrid = basicCopy.getInfluenceGrid();

    for (int i = 0; i < originalGrid.length; i++) {
      assertEquals(originalGrid[i], copiedGrid[i]);
    }
  }

  @Test
  public void testToString() {
    String basicString = basicCard.toString();
    String complexString = complexCard.toString();

    // Check that the toString contains key information
    assertTrue(basicString.contains("Basic Card"));
    assertTrue(basicString.contains("Cost: 1"));
    assertTrue(basicString.contains("Value: 5"));

    assertTrue(complexString.contains("Complex Card"));
    assertTrue(complexString.contains("Cost: 3"));
    assertTrue(complexString.contains("Value: 15"));
  }
}