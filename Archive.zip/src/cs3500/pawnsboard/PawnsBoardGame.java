package cs3500.pawnsboard;

import cs3500.pawnsboard.controller.PawnsBoardControllerImpl;
import cs3500.pawnsboard.model.Card;
import cs3500.pawnsboard.model.DeckConfigReader;
import cs3500.pawnsboard.model.PawnsBoardModel;
import cs3500.pawnsboard.model.PawnsBoardModelImpl;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.Player;
import cs3500.pawnsboard.view.PawnsBoardGUIView;
import cs3500.pawnsboard.view.PawnsBoardGUIViewImpl;

import java.io.File;
import java.util.List;

/**
 * Entry point for the Pawns Board game.
 * This class sets up the model, reads deck configurations, initializes two players,
 * creates two GUI views (one for RED and one for BLUE), attaches controllers,
 * and starts the game.
 */
public final class PawnsBoardGame {

  /**
   * Main method to launch the Pawns Board game.
   * Initializes the game model, loads deck files, sets up the views and controllers,
   * and begins the game loop.
   *
   * @param args command line arguments (not used)
   */
  public static void main(String[] args) {
    try {
      // Create the shared game model
      PawnsBoardModel model = new PawnsBoardModelImpl();

      //Load card decks from text files
      List<Card> redDeck = DeckConfigReader.readDeck("docs" + File.separator + "red_deck.txt");
      List<Card> blueDeck = DeckConfigReader.readDeck("docs" + File.separator + "blue_deck.txt");

      // Initialize game configuration
      model.initGame(5, 7, redDeck, blueDeck, 3);  // 5 rows, 7 columns, hand size 3

      // Create views for RED and BLUE players
      PawnsBoardGUIView redView = new PawnsBoardGUIViewImpl(model);
      PawnsBoardGUIView blueView = new PawnsBoardGUIViewImpl(model);

      // Create human players
      HumanPlayer redPlayer = new HumanPlayer(Player.RED);
      HumanPlayer bluePlayer = new HumanPlayer(Player.BLUE);

      // Attach controllers to connect model, view, and player
      new PawnsBoardControllerImpl(model, redView, redPlayer.getPlayer());
      new PawnsBoardControllerImpl(model, blueView, bluePlayer.getPlayer());

      // Show both player views
      redView.setVisible(true);
      blueView.setVisible(true);

      // Begin the game
      model.startGame();

    } catch (Exception e) {
      System.err.println("Error: " + e.getMessage());
      e.printStackTrace();
    }
  }
}
