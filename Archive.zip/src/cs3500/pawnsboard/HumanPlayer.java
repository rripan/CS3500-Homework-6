package cs3500.pawnsboard;

import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.Player;

/**
 * Represents a human player in the Pawns Board game.
 * This class stores the player's identity (RED or BLUE).
 * Future extensions may allow this class to handle user-specific input or strategies.
 */
public class HumanPlayer {

  private final Player player;

  /**
   * Constructs a human player with the specified player type.
   *
   * @param player the player identity (RED or BLUE)
   */
  public HumanPlayer(Player player) {
    this.player = player;
  }

  /**
   * Returns the player identity (RED or BLUE) associated with this human player.
   *
   * @return the player enum
   */
  public Player getPlayer() {
    return player;
  }


}
