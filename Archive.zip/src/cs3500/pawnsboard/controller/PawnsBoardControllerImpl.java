package cs3500.pawnsboard.controller;

import cs3500.pawnsboard.model.ModelListener;
import cs3500.pawnsboard.model.PawnsBoardModel;
import cs3500.pawnsboard.model.ReadonlyPawnsBoardModel.Player;
import cs3500.pawnsboard.view.PawnsBoardGUIView;

/**
 * Controller implementation for the Pawns Board game.
 * Connects the model and view, handling user inputs and model updates.
 */
public class PawnsBoardControllerImpl implements Features, ModelListener {

  private final PawnsBoardModel model;
  private final PawnsBoardGUIView view;

  // The player this controller is responsible for
  private Player myPlayer;

  // Tracks whether it's currently this player's turn
  private boolean myTurn = false;

  // Stores selected move inputs
  private int selectedCardIndex = -1;
  private int selectedRow = -1;
  private int selectedCol = -1;

  /**
   * Constructs a controller for a player, registering itself with the model and view.
   *
   * @param model  the game model (shared by both players)
   * @param view   the view for this player
   * @param player the player this controller manages (RED or BLUE)
   */
  public PawnsBoardControllerImpl(PawnsBoardModel model, PawnsBoardGUIView view, Player player) {
    this.model = model;
    this.view = view;
    this.myPlayer = player;

    // Register as listener to view (for user inputs) and model (for turn updates)
    view.addFeatures(this);
    model.addModelListener(this);
  }

  /**
   * Handles the event when a card in the player's hand is clicked.
   *
   * @param cardIndex the index of the clicked card
   */
  @Override
  public void handleCardClick(int cardIndex) {
    if (!myTurn) {
      view.displayMessage("Wait for your turn!");
      return;
    }
    this.selectedCardIndex = cardIndex;
    view.highlightCard(cardIndex);
  }

  /**
   * Handles the event when a board cell is clicked.
   *
   * @param row the row index of the clicked cell
   * @param col the column index of the clicked cell
   */
  @Override
  public void handleCellClick(int row, int col) {
    if (!myTurn) {
      view.displayMessage("Wait for your turn!");
      return;
    }
    this.selectedRow = row;
    this.selectedCol = col;
    view.highlightCell(row, col);
  }

  /**
   * Handles the event when the player confirms their move (e.g., pressing ENTER).
   * Tries to place the selected card on the selected cell.
   */
  @Override
  public void handleConfirmMove() {
    if (!myTurn) {
      view.displayMessage("Wait for your turn!");
      return;
    }

    if (selectedCardIndex == -1 || selectedRow == -1 || selectedCol == -1) {
      view.displayMessage("Select a card and a cell before confirming your move.");
      return;
    }

    try {
      model.placeCard(selectedCardIndex, selectedRow, selectedCol);
      myTurn = false;
      view.clearHighlights();
      view.refresh();
    } catch (IllegalArgumentException | IllegalStateException e) {
      view.displayMessage("Invalid move: " + e.getMessage());
    }
  }

  /**
   * Handles the event when the player chooses to pass their turn (e.g., pressing SPACE).
   */
  @Override
  public void handlePassTurn() {
    if (!myTurn) {
      view.displayMessage("Wait for your turn!");
      return;
    }

    model.passTurn();
    myTurn = false;
    view.clearHighlights();
    view.refresh();
  }

  /**
   * Called by the model to notify that it's a particular player's turn.
   * If the player matches this controller, it enables input for the user.
   *
   * @param player the player whose turn it is
   */
  @Override
  public void yourTurn(Player player) {
    if (player == myPlayer) {
      myTurn = true;
      view.displayMessage("It's your turn, " + player + "!");
    }
  }
}
