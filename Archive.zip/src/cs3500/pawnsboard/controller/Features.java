package cs3500.pawnsboard.controller;

/**
 * Represents the set of features that a user can perform in the Pawns Board game.
 * These are the interactions that the view will pass to the controller.
 */
public interface Features {

  /**
   * Called when the player selects a card from their hand.
   *
   * @param cardIndex the index of the selected card
   */
  void handleCardClick(int cardIndex);

  /**
   * Called when the player selects a cell on the game board.
   *
   * @param row the row index of the selected cell
   * @param col the column index of the selected cell
   */
  void handleCellClick(int row, int col);

  /**
   * Called when the player confirms their move (e.g., by pressing ENTER).
   * This usually means placing a selected card on a selected cell.
   */
  void handleConfirmMove();

  /**
   * Called when the player chooses to pass their turn (e.g., by pressing SPACE).
   */
  void handlePassTurn();
}
