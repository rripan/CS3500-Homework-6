package cs3500.pawnsboard.model;

public interface ModelListener {
  /**
   * Called when the model wants to notify a player that it's their turn.
   * @param player the player whose turn it is
   */
  void yourTurn(ReadonlyPawnsBoardModel.Player player);
}
